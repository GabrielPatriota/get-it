#include <SFML/Graphics.hpp>

#include "window.hpp"

using namespace std;
using namespace sf;

WindowCreate windowCreator;

int main()
{
    printf("running\n");
}